package com.example.learning1.utils

enum class navigatioType {
    HOME,
    COMPLETED
}

sealed class NavEvent {
//    data class Navigation(val navType: NavType): NavEvent()
    companion object navigation {
    var navType= navigatioType.HOME
    }
}