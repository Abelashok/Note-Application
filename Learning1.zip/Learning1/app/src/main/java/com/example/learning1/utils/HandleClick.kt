package com.example.learning1.utils

import kotlin.properties.Delegates

interface HandleClick {
    fun onCancelClick()
}

