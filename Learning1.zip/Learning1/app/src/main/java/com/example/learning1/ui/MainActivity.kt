package com.example.learning11.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import com.example.learning1.R
import com.example.learning1.ui.AddNotePage.AddNoteFragment
import com.example.learning1.ui.BottomNavigation.BottomNavigationFragment
import com.example.learning1.ui.HomePage.HomeFragment
import com.example.learning1.utils.HandleClick
import com.example.learning1.utils.NavEvent
import com.example.learning1.utils.NavType
import com.example.learning1.utils.navigatioType
import com.google.android.material.bottomappbar.BottomAppBar


class MainActivity : AppCompatActivity() {
   lateinit var homeFragment: HomeFragment
    lateinit var navigationBar:BottomAppBar
    lateinit var addNoteFragment: AddNoteFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        overridePendingTransition(0,0)
        setContentView(R.layout.activity_main)
        NavEvent.navType = navigatioType.HOME
        homeFragment = HomeFragment()
        addfragment()
        navigationBar =  findViewById(R.id.menu)
       // navigationBar.setItemSelected(2131362019,true,false)
        navigationBar.{
            Log.e("selected id", " " + it)
            val option = when (it) {
                R.id.home -> {
                    NavEvent.navType = navigatioType.HOME
                    homeFragment = HomeFragment()
                    val transaction = (this as AppCompatActivity).supportFragmentManager.beginTransaction()
                    transaction.replace(com.example.learning1.R.id.home,homeFragment)
                    transaction.addToBackStack(null)
                    transaction.commit()

                }
                R.id.complete ->{
                    NavEvent.navType = navigatioType.COMPLETED

                    homeFragment = HomeFragment()
                    val transaction = (this as AppCompatActivity).supportFragmentManager.beginTransaction()
                    transaction.replace(com.example.learning1.R.id.home,homeFragment)
                    transaction.addToBackStack(null)
                    transaction.commit()
                    Log.e("selected id", "2 HIIIIIIIIIII" )}
                R.id.add -> {
                    addNoteFragment = AddNoteFragment()
                    val transaction = (this as AppCompatActivity).supportFragmentManager.beginTransaction()
                    transaction.replace(com.example.learning1.R.id.home,addNoteFragment)
                    transaction.addToBackStack(null)
                    transaction.commit()
                }

//                R.id.profile ->{}
                else -> {}
            }
        }


    }


    fun addfragment() {
        supportFragmentManager.beginTransaction()
            .add(R.id.home,homeFragment)
            .commitAllowingStateLoss()
    }

    fun onCancelClick() {
        navigationBar.setItemSelected(2131362019,true,false )
    }


}